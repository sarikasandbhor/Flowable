update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'common.schema.version';

update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'entitylink.schema.version';

alter table ACT_RU_IDENTITYLINK add SUB_SCOPE_ID_ nvarchar(255);

create index ACT_IDX_IDENT_LNK_SUB_SCOPE on ACT_RU_IDENTITYLINK(SUB_SCOPE_ID_, SCOPE_TYPE_);

update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'identitylink.schema.version';

alter table ACT_HI_IDENTITYLINK add SUB_SCOPE_ID_ nvarchar(255);

create index ACT_IDX_HI_IDENT_LNK_SUB_SCOPE on ACT_HI_IDENTITYLINK(SUB_SCOPE_ID_, SCOPE_TYPE_);

update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'job.schema.version';

update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'batch.schema.version';

alter table ACT_RU_TASK add PROPAGATED_STAGE_INST_ID_ nvarchar(255);

update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'task.schema.version';

alter table ACT_HI_TASKINST add PROPAGATED_STAGE_INST_ID_ nvarchar(255);

update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'variable.schema.version';

update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'eventsubscription.schema.version';
alter table ACT_RU_EXECUTION add REFERENCE_ID_ nvarchar(255);
alter table ACT_RU_EXECUTION add REFERENCE_TYPE_ nvarchar(255);

alter table ACT_RU_EXECUTION add PROPAGATED_STAGE_INST_ID_ nvarchar(255);

update ACT_GE_PROPERTY set VALUE_ = '6.5.0.5' where NAME_ = 'schema.version';


UPDATE [ACT_CMMN_DATABASECHANGELOGLOCK] SET [LOCKED] = 1, [LOCKEDBY] = '192.168.1.15 (192.168.1.15)', [LOCKGRANTED] = '2019-12-04T11:52:21.822' WHERE [ID] = 1 AND [LOCKED] = 0

ALTER TABLE [ACT_CMMN_RU_PLAN_ITEM_INST] ADD [EXTRA_VALUE_] [varchar](255)

ALTER TABLE [ACT_CMMN_HI_PLAN_ITEM_INST] ADD [EXTRA_VALUE_] [varchar](255)

INSERT INTO [ACT_CMMN_DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE], [DEPLOYMENT_ID]) VALUES ('9', 'flowable', 'org/flowable/cmmn/db/liquibase/flowable-cmmn-db-changelog.xml', GETDATE(), 8, '7:20048a5d52039eaabb32dbb30240fc08', 'addColumn tableName=ACT_CMMN_RU_PLAN_ITEM_INST; addColumn tableName=ACT_CMMN_HI_PLAN_ITEM_INST', '', 'EXECUTED', NULL, NULL, '3.5.3', '5456742868')

UPDATE [ACT_CMMN_DATABASECHANGELOGLOCK] SET [LOCKED] = 0, [LOCKEDBY] = NULL, [LOCKGRANTED] = NULL WHERE [ID] = 1



UPDATE [ACT_DMN_DATABASECHANGELOGLOCK] SET [LOCKED] = 1, [LOCKEDBY] = '192.168.1.15 (192.168.1.15)', [LOCKGRANTED] = '2019-12-04T11:52:29.598' WHERE [ID] = 1 AND [LOCKED] = 0

UPDATE [ACT_DMN_DATABASECHANGELOGLOCK] SET [LOCKED] = 0, [LOCKEDBY] = NULL, [LOCKGRANTED] = NULL WHERE [ID] = 1

