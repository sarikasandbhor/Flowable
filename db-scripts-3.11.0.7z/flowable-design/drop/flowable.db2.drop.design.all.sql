drop table ACT_DE_MODEL_TAG;

drop index idx_model_resource;

drop table ACT_DE_MODEL_RESOURCE;
drop table FLW_DE_TENANT;
drop table ACT_DE_MODEL_METADATA;
drop table ACT_DE_TOKEN;
drop table ACT_DE_USER;
drop table ACT_DE_MODEL_RELATION;
drop table ACT_DE_MODEL_TAG_RELATION;
drop table ACT_DE_MODEL_TAG;

drop index idx_proc_mod_history_proc;

drop table ACT_DE_MODEL_HISTORY;

drop index idx_proc_mod_created;

drop table ACT_DE_MODEL;
drop table ACT_DE_DATABASECHANGELOG;
drop table ACT_DE_DATABASECHANGELOGLOCK;

drop table FLW_LIC_LICENSE;
drop table FLW_LIC_DATABASECHANGELOG;
drop table FLW_LIC_DATABASECHANGELOGLOCK;

drop index FLW_IDX_PALETTE_DEF_DPLY;
drop index FLW_IDX_PALETTE_DEF_UNIQ;

drop table FLW_PALETTE_DEFINITION;

drop index FLW_IDX_PALETTE_RSRC_DPL;

drop table FLW_PALETTE_DEPLOYMENT_RES;
drop table FLW_PALETTE_DEPLOYMENT;
drop table FLW_PAL_DATABASECHANGELOG;
drop table FLW_PAL_DATABASECHANGELOGLOCK;
