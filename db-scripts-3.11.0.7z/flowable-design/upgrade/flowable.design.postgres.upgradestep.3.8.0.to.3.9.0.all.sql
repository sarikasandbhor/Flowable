
UPDATE flw_pal_databasechangeloglock SET LOCKED = TRUE, LOCKEDBY = '192.168.68.122 (192.168.68.122)', LOCKGRANTED = '2021-02-26 08:27:04.403' WHERE ID = 1 AND LOCKED = FALSE;

UPDATE flw_pal_databasechangeloglock SET LOCKED = FALSE, LOCKEDBY = NULL, LOCKGRANTED = NULL WHERE ID = 1;


UPDATE flw_lic_databasechangeloglock SET LOCKED = TRUE, LOCKEDBY = '192.168.68.122 (192.168.68.122)', LOCKGRANTED = '2021-02-26 08:27:04.963' WHERE ID = 1 AND LOCKED = FALSE;

UPDATE flw_lic_databasechangeloglock SET LOCKED = FALSE, LOCKEDBY = NULL, LOCKGRANTED = NULL WHERE ID = 1;


UPDATE act_de_databasechangeloglock SET LOCKED = TRUE, LOCKEDBY = '192.168.68.122 (192.168.68.122)', LOCKGRANTED = '2021-02-26 08:27:05.048' WHERE ID = 1 AND LOCKED = FALSE;

CREATE TABLE ACT_DE_MODEL_TAG_RELATION (id VARCHAR(255) NOT NULL, model_tag_id VARCHAR(255) NOT NULL, model_id VARCHAR(255) NOT NULL, CONSTRAINT PK_ACT_DE_MODEL_TAG_RELATION PRIMARY KEY (id));

ALTER TABLE ACT_DE_MODEL_TAG_RELATION ADD CONSTRAINT fk_tag_relation_tag FOREIGN KEY (model_tag_id) REFERENCES ACT_DE_MODEL_TAG (id);

ALTER TABLE ACT_DE_MODEL_TAG_RELATION ADD CONSTRAINT fk_tag_relation_model FOREIGN KEY (model_id) REFERENCES ACT_DE_MODEL (id);

INSERT INTO ACT_DE_MODEL_TAG_RELATION
            (
            id,
            model_tag_id,
            model_id
            )
            SELECT
            md5(random()::text || clock_timestamp()::text)::uuid AS id,
            model_tag.id as model_tag_id,
            model.id as model_id
            FROM
            ACT_DE_MODEL_TAG model_tag,
            ACT_DE_MODEL model
            WHERE
            model_tag.name = model.tag;

ALTER TABLE ACT_DE_MODEL DROP COLUMN tag;

ALTER TABLE ACT_DE_MODEL_HISTORY RENAME COLUMN tag TO tags_json;

INSERT INTO act_de_databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID) VALUES ('14', 'flowable', 'META-INF/liquibase/flowable-modeler-app-db-changelog.xml', NOW(), 13, '7:7b6d3dfa3fac86837e71a6ac202b3a40', 'createTable tableName=ACT_DE_MODEL_TAG_RELATION; addForeignKeyConstraint baseTableName=ACT_DE_MODEL_TAG_RELATION, constraintName=fk_tag_relation_tag, referencedTableName=ACT_DE_MODEL_TAG; addForeignKeyConstraint baseTableName=ACT_DE_MODEL_TAG_RELA...', '', 'EXECUTED', NULL, NULL, '3.5.3', '4324425109');

UPDATE act_de_databasechangeloglock SET LOCKED = FALSE, LOCKEDBY = NULL, LOCKGRANTED = NULL WHERE ID = 1;

