package com.example.training.controller;

import com.example.training.service.DecisionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DecisionController {

    @Autowired
    private DecisionService decisionService;

    @GetMapping("/getDecision")
    public ResponseEntity<Map<String,Object>> getDecision(@RequestParam("decisionKey") String decisionKey, @RequestBody Map<String,Object> decisionVars)
    {
        return new ResponseEntity<>(decisionService.executeDecision(decisionKey,decisionVars), HttpStatus.OK);
    }
}
