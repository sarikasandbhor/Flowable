package com.example.training.service;

import java.util.Map;

public interface DecisionService {
    public Map<String,Object> executeDecision(String decisionTableKey, Map<String,Object> decisionVars);
}
