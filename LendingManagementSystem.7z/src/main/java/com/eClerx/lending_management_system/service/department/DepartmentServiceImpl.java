package com.eClerx.lending_management_system.service.department;

import com.eClerx.lending_management_system.entity.Department;
import com.eClerx.lending_management_system.repository.department.DepartmentDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DepartmentServiceImpl implements DepartmentService{
@Autowired
    DepartmentDAO departmentDAO;

    @Override
    public Department findById(int i) {
        Optional<Department> department= departmentDAO.findById(i);
        if(department.isPresent())
            return department.get();
        else
          throw new RuntimeException("Department with this is is not present"+i);

    }
}
