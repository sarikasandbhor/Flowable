package com.eClerx.lending_management_system.service.user;

import com.eClerx.lending_management_system.dto.LoanCustomerDTO;
import com.eClerx.lending_management_system.entity.User;
import org.mapstruct.Mapper;

@Mapper
public interface LoanCustomerMapper
{
     //   User sourceToDestination(LoanCustomerDTO source);
}
