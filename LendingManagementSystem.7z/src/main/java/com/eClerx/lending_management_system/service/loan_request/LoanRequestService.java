package com.eClerx.lending_management_system.service.loan_request;

import com.eClerx.lending_management_system.dto.CompleteTaskDTO;
import com.eClerx.lending_management_system.dto.LoanCustomerDTO;
import com.eClerx.lending_management_system.entity.LoanRequest;
import com.eClerx.lending_management_system.entity.User;
import org.springframework.stereotype.Service;

@Service
public interface LoanRequestService
{
   void save(LoanCustomerDTO loanCustomerDTO, User user);
   LoanRequest findById(int i);

   void updateStatus(CompleteTaskDTO completeTaskDTO);

    int findByDepartment(Integer loanRequestId);

    /* List<LoanRequest> findAll();*/

    /*LoanRequest getLoanRequest(Integer loanId);*/
}
