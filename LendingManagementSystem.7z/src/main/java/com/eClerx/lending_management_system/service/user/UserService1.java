package com.eClerx.lending_management_system.service.user;

import com.eClerx.lending_management_system.dto.LoanCustomerDTO;
import org.springframework.stereotype.Service;


@Service
public interface UserService1
{
    void save(LoanCustomerDTO loanCustomerDTO);

    /*void view(PendingLoanRequestDTO pendingLoanRequestDTO);

*/
}
