package com.eClerx.lending_management_system.service.department;

import com.eClerx.lending_management_system.entity.Department;
import org.springframework.stereotype.Service;

@Service
public interface DepartmentService
{
    Department findById(int i);
}
