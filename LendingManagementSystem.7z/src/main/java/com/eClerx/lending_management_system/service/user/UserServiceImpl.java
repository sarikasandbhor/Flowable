package com.eClerx.lending_management_system.service.user;


import com.eClerx.lending_management_system.dto.LoanCustomerDTO;
import com.eClerx.lending_management_system.entity.User;
import com.eClerx.lending_management_system.repository.customer.UserDAO;
import com.eClerx.lending_management_system.service.loan_request.LoanRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl implements UserService1
{
    @Autowired
    UserDAO userDAO;
    @Autowired
    LoanRequestService loanRequestService;
    @Override
    public void save(LoanCustomerDTO loanCustomerDTO)
    {
        User user=new User();
        user.setUserName(loanCustomerDTO.getUser().getUserName());
        user.setAddress(loanCustomerDTO.getUser().getAddress());
        user.setMobile(loanCustomerDTO.getUser().getMobile());
        user.setEmail(loanCustomerDTO.getUser().getEmail());
        user.setPanCard(loanCustomerDTO.getUser().getPanCard());
        user.setAdhar(loanCustomerDTO.getUser().getAdhar());
        user.setDob(loanCustomerDTO.getUser().getDob());
        user.setCollateral(loanCustomerDTO.getUser().getCollateral());
        user.setIncome(loanCustomerDTO.getUser().getIncome());
        user.setCibilScore(loanCustomerDTO.getUser().getCibilScore());
        user.setAccountNumber(loanCustomerDTO.getUser().getAccountNumber());
        user.setDepartment(loanCustomerDTO.getDepartment());
        userDAO.save(user);
        if(loanCustomerDTO.getDepartment().getDeptId()==5)
        loanRequestService.save(loanCustomerDTO,user);
    }

  /*  @Override
    public void view(PendingLoanRequestDTO pendingLoanRequestDTO) {
        User user=new User();

    }*/
   /* @Autowired
    CustomerDAO customerDao;
    @Override
    public Customer save(Customer customer) {
        return customerDao.save(customer);
    }*/
}
