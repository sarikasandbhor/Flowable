package com.eClerx.lending_management_system.service.process;


import com.eClerx.lending_management_system.dto.CompleteTaskDTO;
import com.eClerx.lending_management_system.dto.LoanCustomerDTO;
import com.eClerx.lending_management_system.entity.ProcessInstanceJson;
import com.eClerx.lending_management_system.service.approval_history.ApprovalHistoryService;
import com.eClerx.lending_management_system.service.loan_request.LoanRequestService;
import com.eClerx.lending_management_system.service.user.UserService1;
import org.flowable.common.rest.variable.DateRestVariableConverter;
import org.flowable.common.rest.variable.EngineRestVariable;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.impl.form.DateFormType;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


@Service
public class ProcessServiceImpl implements ProcessService1
{
    @Autowired
    RuntimeService runtimeService;
    @Autowired
    ApprovalHistoryService approvalHistoryService;
    @Autowired
    private UserService1 userService1;
    @Autowired
    private LoanRequestService loanRequestService;
    public void startProcess(LoanCustomerDTO loanCustomerDTO) throws ParseException {
        Map<String, Object> variableMap = new HashMap<String, Object>();
        variableMap.put("fullname", loanCustomerDTO.getUser().getUserName().toString());
        variableMap.put("address", loanCustomerDTO.getUser().getAddress().toString());
        variableMap.put("mobilenumber", loanCustomerDTO.getUser().getMobile().toString());
        variableMap.put("email", loanCustomerDTO.getUser().getEmail().toString());

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = formatter.format(loanCustomerDTO.getUser().getDob());


        variableMap.put("dob",formattedDate);
        variableMap.put("pan", loanCustomerDTO.getUser().getPanCard().toString());
        variableMap.put("collateraldetails", loanCustomerDTO.getUser().getCollateral().toString());
        variableMap.put("aadhar", loanCustomerDTO.getUser().getAdhar().toString());
        variableMap.put("monthlyincome",  loanCustomerDTO.getUser().getIncome());
        variableMap.put("amount", loanCustomerDTO.getLoanRequest().getRequestedAmount());

        ProcessInstance processInstance = null;
        processInstance = runtimeService.startProcessInstanceByKey("Lending_Automation_Process",variableMap);
        logger.info("ProcessInstanceId :"+processInstance.getProcessInstanceId());
        userService1.save(loanCustomerDTO);
        System.out.println("Instance Id :"+processInstance.getProcessInstanceId());
    }


    Logger logger = (Logger) LoggerFactory.getLogger(ProcessServiceImpl.class);

    @Autowired
    TaskService taskService;

    @Override
    public List<ProcessInstanceJson> getProcessInstanceID() {
        List<ProcessInstance> processInstances = null;
        List<ProcessInstanceJson> processInstanceJson = new ArrayList<ProcessInstanceJson>();
        try {
            processInstances = runtimeService.createProcessInstanceQuery().active().list();

            for (ProcessInstance processInstance : processInstances) {
                ProcessInstanceJson processlist = new ProcessInstanceJson();
                processlist.setProcessInstanceId(processInstance.getProcessInstanceId());
                processlist.setProcessId(processInstance.getProcessDefinitionId());
                processlist.setStartDate(processInstance.getStartTime());
                processlist.setEndDate(processInstance.getStartTime());

                processInstanceJson.add(processlist);

            }
            logger.info("###### End ProcessDefinationServiceImpl #######  /startProcessInstance");
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("######processInstance.getProcessInstanceId()-- ########" + processInstanceJson);
        return processInstanceJson;
    }

    /*@Override
    public void startProcessService(String key, UserRequestForm userRequestForm) {
        Map<String, Object> variableMap = new HashMap<String, Object>();
        variableMap.put("fullname", userRequestForm.getFullname());
        variableMap.put("add", userRequestForm.getAdd());
        variableMap.put("mobilenumber", userRequestForm.getMobilenumber());
        variableMap.put("email", userRequestForm.getEmail());
        variableMap.put("dob", userRequestForm.getDob());
        variableMap.put("pan", userRequestForm.getPan());
        variableMap.put("adcollateraldetailsd", userRequestForm.getCollateraldetails());
        variableMap.put("aadhar", userRequestForm.getAadhar());
        variableMap.put("monthlyincome", userRequestForm.getMonthlyincome());
        variableMap.put("amount", userRequestForm.getAmount());

        runtimeService.startProcessInstanceByKey(key, variableMap);//LendingProcess
    }*/

    @Override
    public List<Map<String, Object>> getTasks(String assignee) {
        List<Task> tasks = (List<Task>) taskService.createTaskQuery().active().taskCandidateOrAssigned(assignee).list();
        List<Map<String, Object>> customTaskList = new ArrayList<>();
        for (Task task : tasks) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("taskId", task.getId());
            map.put("taskDefinitionKey", task.getTaskDefinitionKey());
            map.put("taskName", task.getName());
            map.put("startDate",task.getCreateTime());

            customTaskList.add(map);
        }
        System.out.println("#### Get Task list/"+customTaskList);
        return customTaskList;
    }

    @Override
    public String claimTask(String taskId, String userId) {

        taskService.claim(taskId, userId);
        System.out.println("Task Claimed to user " + userId + " for taskId" + taskId);
        return "Claimed";
    }
    @Override
    public String completeTask(String taskId,CompleteTaskDTO completeTaskDTO) {
        taskService.complete(taskId, (Map<String, Object>) completeTaskDTO);
        return approvalHistoryService.updateLoanRequest(completeTaskDTO);
    }
}
