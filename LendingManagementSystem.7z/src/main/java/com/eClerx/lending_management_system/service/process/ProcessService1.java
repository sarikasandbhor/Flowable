package com.eClerx.lending_management_system.service.process;


import com.eClerx.lending_management_system.dto.CompleteTaskDTO;
import com.eClerx.lending_management_system.dto.LoanCustomerDTO;
import com.eClerx.lending_management_system.entity.ProcessInstanceJson;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;


@Service
public interface ProcessService1
{
    public void startProcess(LoanCustomerDTO loanCustomerDTO) throws ParseException;

    public String claimTask(String taskId, String userId);

    public List<ProcessInstanceJson> getProcessInstanceID() ;

    public List<Map<String, Object>> getTasks(String assignee);

     public String completeTask(String taskId,CompleteTaskDTO completeTaskDTO);
}
