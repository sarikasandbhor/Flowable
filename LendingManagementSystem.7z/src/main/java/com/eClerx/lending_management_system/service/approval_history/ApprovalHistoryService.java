package com.eClerx.lending_management_system.service.approval_history;

import com.eClerx.lending_management_system.dto.CompleteTaskDTO;
import com.eClerx.lending_management_system.entity.LoanRequest;
import org.springframework.stereotype.Service;

@Service
public interface ApprovalHistoryService {
    void save(LoanRequest loanCustomerDTO);

     String updateLoanRequest(CompleteTaskDTO completeTaskDTO);
}
