package com.eClerx.lending_management_system.service.approval_history;

import com.eClerx.lending_management_system.dto.CompleteTaskDTO;
import com.eClerx.lending_management_system.entity.Approval_History;
import com.eClerx.lending_management_system.entity.LoanRequest;
import com.eClerx.lending_management_system.repository.approval_history.ApprovalHistoryDAO;
import com.eClerx.lending_management_system.repository.department.DepartmentDAO;
import com.eClerx.lending_management_system.repository.loan_request.LoanRequestDAO;
import com.eClerx.lending_management_system.service.department.DepartmentService;
import com.eClerx.lending_management_system.service.loan_request.LoanRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApprovalHistoryServiceImpl implements ApprovalHistoryService {
    @Autowired
    ApprovalHistoryDAO approvalHistoryDAO;

    @Autowired
    LoanRequestDAO loanRequestDAO;
    @Autowired
    DepartmentService departmentService;
    @Autowired
    DepartmentDAO departmentDAO;
    @Autowired
    LoanRequestService loanRequestService;
    @Override
    public void save(LoanRequest loanRequest) {
        Approval_History approval_history = new Approval_History();
        approval_history.setLoanRequest(loanRequest);
        approval_history.setDepartment(departmentService.findById(1));
        approval_history.setStatus("PENDING");
       // approval_history.setStatusReason("PENDING");

        approvalHistoryDAO.save(approval_history);
    }

    @Override
    public String updateLoanRequest(CompleteTaskDTO completeTaskDTO)
    {
        int id =loanRequestService.findByDepartment(completeTaskDTO.getUserId());
        System.out.println(id);
        approvalHistoryDAO.updateStatus
                (completeTaskDTO.getLoanRequestId(), id, completeTaskDTO.getStatus());
        System.out.println(completeTaskDTO.getStatus());
        if(completeTaskDTO.getStatus().equals("approved"))
        {

            if(id==5)
            {
                loanRequestService.updateStatus(completeTaskDTO);
            }
            else if(id!=4)
            {
                Approval_History approval_history = new Approval_History();
                approval_history.setLoanRequest(loanRequestService.findById(completeTaskDTO.getLoanRequestId()));
                approval_history.setStatus("PENDING");
                if (id == 1)
                    approval_history.setDepartment(departmentService.findById(2));
                else if (id == 2)
                    approval_history.setDepartment(departmentService.findById(3));
                else if (id == 3)
                    approval_history.setDepartment(departmentService.findById(4));
                approvalHistoryDAO.save(approval_history);
            }
            else if(id==4)
            {
                //loan summary table gets created
            }
            // approval_history.setStatusReason("PENDING");
        }
        else if(completeTaskDTO.getStatus().equals("rejected"))
        {
            loanRequestService.updateStatus(completeTaskDTO);
        }

        return "updated";
        //   approvalHistoryDAO.save(approval_history);
        //return approval_history.getApproval_history();

    }
}

