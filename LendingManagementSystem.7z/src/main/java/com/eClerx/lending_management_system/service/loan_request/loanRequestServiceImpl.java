package com.eClerx.lending_management_system.service.loan_request;

import com.eClerx.lending_management_system.dto.CompleteTaskDTO;
import com.eClerx.lending_management_system.dto.LoanCustomerDTO;
import com.eClerx.lending_management_system.entity.LoanRequest;
import com.eClerx.lending_management_system.entity.User;
import com.eClerx.lending_management_system.repository.loan_request.LoanRequestDAO;
import com.eClerx.lending_management_system.service.approval_history.ApprovalHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class loanRequestServiceImpl implements LoanRequestService
{
    @Autowired
    LoanRequestDAO loanRequestDAO;
    @Autowired
    ApprovalHistoryService approvalHistoryService;

    @Override
    public void save(LoanCustomerDTO loanCustomerDTO, User user)
    {
        LoanRequest loanRequest=new LoanRequest();
       // System.out.println(loanCustomerDTO.getUser().getUserName());
        loanRequest.setUser(user);
        loanRequest.setLoanStatus("pending");
        loanRequest.setRequestedAmount(loanCustomerDTO.getLoanRequest().getRequestedAmount());
        loanRequestDAO.save(loanRequest);

        approvalHistoryService.save(loanRequest);
    }

    @Override
    public LoanRequest findById(int i) {
        Optional<LoanRequest> loanRequest= loanRequestDAO.findById(i);
        if(loanRequest.isPresent())
            return loanRequest.get();
        else
            throw new RuntimeException("Loan Request with this is is not present"+i);

    }

    @Override
    public void updateStatus(CompleteTaskDTO completeTaskDTO) {
        loanRequestDAO.updateStatus(completeTaskDTO.getLoanRequestId(),completeTaskDTO.getStatus());
    }

    @Override
    public int findByDepartment(Integer loanRequestId) {
        return loanRequestDAO.findByDepartment(loanRequestId);

    }

    /*@Override
    public List<LoanRequest> findAll() {
        return loanRequestDAO.findAll();
    }

    @Override
    public LoanRequest getLoanRequest(Integer loanId)
    {
        Optional<LoanRequest> loanRequest = loanRequestDAO.findById(loanId);
        if (loanRequest.isPresent())
            return loanRequest.get();
        else
            throw new RuntimeException("Loan Request with this id is not present" + loanId);
    }
*/


   /* private static List<LoanRequest> list=new ArrayList<>();
    static {











    }
    @Autowired
    private LoanRequestDAO loanRequestDAO;*/

   /* @Override
        public LoanRequest save(LoanRequest loanRequest, Integer customerId)
    {
        return loanRequestDAO.save(loanRequest,customerId);
    }*/
/*
    @Override
    public List<LoanRequest> getList()
    {
        return loanRequestDAO.findAll();
    }

    @Override
    public LoanRequest saveLoanRequest(LoanRequest loanRequest) {
       return loanRequestDAO.save(loanRequest);
    }

    @Override
    public LoanRequest getLoanRequest(int loanRequestId) {
       Optional<LoanRequest> op= loanRequestDAO.findById(loanRequestId);
       if(op.isPresent())
           return op.get();
       else throw new RuntimeException("not present");
    }

    @Override
    public LoanRequest updateLoanRequest(LoanRequest loanRequest) {
       return loanRequestDAO.save(loanRequest);
    }*/
}
