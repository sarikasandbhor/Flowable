package com.eClerx.lending_management_system.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class LoanSummary
{
    @Id
    @GeneratedValue
    private Integer loanSummaryId;

    @OneToOne
    /*@JoinColumn(name = "fk_loanRequest")*/
    private LoanRequest loanRequest;
    private Integer sanctionedAmount;
    private String roi;
    private String tenure;
    private Integer processingFee;
    private String tnc;
}
