package com.eClerx.lending_management_system.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Objects;

@Data
public class Approval_Historypk implements Serializable {
    private Integer department;
    private Integer loanRequest;
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Approval_Historypk that = (Approval_Historypk) o;
        return Objects.equals(department, that.department) && Objects.equals(loanRequest, that.loanRequest);
    }

    @Override
    public int hashCode() {
        return Objects.hash(department, loanRequest);
    }

}
