package com.eClerx.lending_management_system.entity;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@ApiModel(description = "loan request details")
@Entity
public class LoanRequest
{
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer loanRequestId;

    @OneToOne
    private User user;
    private Integer requestedAmount;
    private String loanStatus;

   @OneToMany(mappedBy = "loanRequest")
   private List<Approval_History> departmentList;

}
