package com.eClerx.lending_management_system.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@IdClass(Approval_Historypk.class)
public class Approval_History implements Serializable
{
    @Id
    @ManyToOne
    @JoinColumn(name="dept_id",referencedColumnName = "deptId")
    private Department department;

    @Id
    @ManyToOne
    @JoinColumn(name="loan_request_id",referencedColumnName = "loanRequestId")
    private LoanRequest loanRequest;

    @Column(name="status")
    private String status;
}
