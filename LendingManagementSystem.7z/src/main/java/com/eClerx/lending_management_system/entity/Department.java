package com.eClerx.lending_management_system.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Department
{
    @Id
    private Integer deptId;
    private String deptName;
   // private String deptMail;

    @OneToMany(mappedBy = "department")
    private List<Approval_History> loanRequestList;


    /*@OneToMany(mappedBy="department")
    List<Approval_History> approval_history;e
*/
           /* =new ArrayList<>();

    public  List<Approval_History> getApprovalHistory()
    {
        return approval_history;
    }*/
}
