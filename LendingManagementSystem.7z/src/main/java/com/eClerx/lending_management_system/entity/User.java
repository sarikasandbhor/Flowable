package com.eClerx.lending_management_system.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
public class User
{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer userId;

    @ManyToOne
    private Department department;

    private String userName;
    private String mobile;
    private String email;
    private String address;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date dob;
    private String panCard;
    private String adhar;
    private String collateral;
    private Integer income;
    private Integer cibilScore;
    private String accountNumber;

   /* @OneToOne(cascade = CascadeType.ALL,mappedBy = "user")
    private LoanRequest loanRequest;*/
}
