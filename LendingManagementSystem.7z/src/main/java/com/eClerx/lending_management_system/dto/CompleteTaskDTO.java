package com.eClerx.lending_management_system.dto;

import lombok.Data;

@Data
public class CompleteTaskDTO
{
    private Integer userId;
    private Integer loanRequestId;
  //  private String taskId;
  //  private String action;
    private String status;
}


