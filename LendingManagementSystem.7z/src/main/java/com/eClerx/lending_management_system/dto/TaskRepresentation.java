package com.eClerx.lending_management_system.dto;

import lombok.Data;
@Data
public class TaskRepresentation
{
        private String id;
        private String name;

        public TaskRepresentation(String id, String name) {
            this.id = id;
            this.name = name;
        }
}
