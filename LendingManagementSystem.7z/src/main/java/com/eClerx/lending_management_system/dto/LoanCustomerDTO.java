package com.eClerx.lending_management_system.dto;

import com.eClerx.lending_management_system.entity.Department;
import com.eClerx.lending_management_system.entity.LoanRequest;
import com.eClerx.lending_management_system.entity.User;
import lombok.Data;

@Data
public class LoanCustomerDTO
{
    private Department department;
    private User user;
    private LoanRequest loanRequest;
}
