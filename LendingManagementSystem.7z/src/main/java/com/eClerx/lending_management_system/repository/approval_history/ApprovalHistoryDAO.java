package com.eClerx.lending_management_system.repository.approval_history;

import com.eClerx.lending_management_system.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
@Repository
@Transactional
public interface ApprovalHistoryDAO extends JpaRepository<Approval_History,Approval_Historypk>
{
    @Modifying
    @Query(value = "UPDATE approval_history SET status = :status WHERE dept_id = :dept_id AND loan_request_id = :loan_request_id", nativeQuery = true)
    public void updateStatus(@Param("loan_request_id") Integer loan_request_id, @Param("dept_id") Integer dept_id, @Param("status") String status);

   // Approval_History findByLoanRequestAndDepartment(LoanRequest loanRequest, Department department);
    Approval_History findByStatus(String status);
}
