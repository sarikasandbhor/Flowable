package com.eClerx.lending_management_system.repository.loan_request;

import com.eClerx.lending_management_system.entity.Approval_History;
import com.eClerx.lending_management_system.entity.LoanRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface LoanRequestDAO extends JpaRepository<LoanRequest, Integer>
{
    //@Modifying
    @Query(value = "SELECT department_dept_id FROM user WHERE user_id = :user_id", nativeQuery = true)
    int findByDepartment(Integer user_id);

    @Modifying
    @Query(value = "UPDATE loan_request SET loan_status = :loan_status WHERE loan_request_id = :loan_request_id", nativeQuery = true)
    void updateStatus(@Param("loan_request_id") Integer loan_request_id,@Param("loan_status") String loan_status);

}
