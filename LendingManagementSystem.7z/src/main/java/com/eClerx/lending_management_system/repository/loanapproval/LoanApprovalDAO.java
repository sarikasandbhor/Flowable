package com.eClerx.lending_management_system.repository.loanapproval;

import com.eClerx.lending_management_system.entity.LoanRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanApprovalDAO extends JpaRepository<LoanRequest, Integer> {
}
