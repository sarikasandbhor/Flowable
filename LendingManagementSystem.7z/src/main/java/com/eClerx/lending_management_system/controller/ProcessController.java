package com.eClerx.lending_management_system.controller;

import com.eClerx.lending_management_system.dto.CompleteTaskDTO;
import com.eClerx.lending_management_system.dto.LoanCustomerDTO;
import com.eClerx.lending_management_system.service.loan_request.LoanRequestService;
import com.eClerx.lending_management_system.service.process.ProcessService1;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.flowable.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ProcessController
{
    @Autowired
    private ProcessService1 processService;

    @Autowired
    RuntimeService runtimeService;

    @Autowired
    LoanRequestService loanRequestService;

    @PostMapping(value="/process")
    public void startProcessInstance(@RequestBody LoanCustomerDTO loanCustomerDTO) throws JsonProcessingException, ParseException {
        System.out.println("hello this app is running.....................");
        processService.startProcess(loanCustomerDTO);
    }

    @GetMapping("/getTasks")
    public List<Map<String, Object>> getTasks(@RequestParam String assignee)
    {
        return processService.getTasks(assignee);
    }

    @PostMapping("/claimTask")
    public void startProcessService(@RequestParam String taskId, @RequestParam String userId) {

        System.out.println("####task claim initiated/");
        processService.claimTask(taskId,userId);
    }
     @PostMapping("/completeTask")
        public String completeTask(@RequestParam("taskId") String taskId,@RequestBody CompleteTaskDTO completeTaskDTO)
     {
            return processService.completeTask(taskId,completeTaskDTO);
     }
}