package com.example.demo.service;


import com.example.demo.entity.User;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {
    public ResponseEntity<Object> uploadToLocal(MultipartFile file, User user);
    public ResponseEntity<Object> uploadToLocal(MultipartFile file);
}
