package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.service.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class DemoController {
    @Autowired
    private FileUploadService fileUploadService;

    @GetMapping("/hello")
    public void hello() {
        System.out.println("Hello World!");
    }



    @PostMapping("/upload/local")
    public ResponseEntity<String> uploadLocal(@RequestPart("file") MultipartFile multipartFile, @RequestPart User user) {
        fileUploadService.uploadToLocal(multipartFile, user);
        if (multipartFile.isEmpty()) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Request must contain file");
        }
        return ResponseEntity.ok("working");
    }

    @PostMapping("/upload/file")
    public ResponseEntity<String> uploadLocal(@RequestParam("file") MultipartFile multipartFile) {
        fileUploadService.uploadToLocal(multipartFile);
        if (multipartFile.isEmpty()) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Request must contain file");
        }
        return ResponseEntity.ok("working");
    }
}
