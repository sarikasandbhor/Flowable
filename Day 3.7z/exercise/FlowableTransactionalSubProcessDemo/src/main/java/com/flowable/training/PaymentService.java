package com.flowable.training;

import org.flowable.engine.delegate.BpmnError;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PaymentService implements JavaDelegate {
	Logger logger = LoggerFactory.getLogger(PaymentService.class);
	
	@Override
	public void execute(final DelegateExecution execution) {
		System.out.println("Payment service executing");
		Integer paymentamount = (Integer) execution.getVariable("paymentamount");
		
		logger.info("Making payment  : {} INR", paymentamount);
		
		throw new BpmnError("paymentError", "Payment error occured while transfering amount");
		
	}
}