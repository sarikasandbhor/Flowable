package com.flowable.training;

import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;

import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.test.FlowableRule;
import org.junit.Rule;
import org.junit.Test;

public class ProcessTransactionalSubProcessDemoTest {

	private String filename = "src/main/resources/diagrams/Transactional_SubProcess_Demo.bpmn";

	@Rule
	public FlowableRule activitiRule = new FlowableRule();

	@Test
	public void startProcess() throws Exception {
		RepositoryService repositoryService = activitiRule.getRepositoryService();
		System.out.println("Repository Service Started");
		repositoryService.createDeployment().addInputStream("Transactional_SubProcess_Demo.bpmn20.xml",
				new FileInputStream(filename)).deploy();
		System.out.println("Process is deployed");

		RuntimeService runtimeService = activitiRule.getRuntimeService();
		System.out.println("Runtime Service Started");
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("transactionalSubProcesstDemo");
		assertNotNull(processInstance.getId());
		System.out.println("id " + processInstance.getId() + " "+processInstance.getProcessDefinitionId());
	}
}