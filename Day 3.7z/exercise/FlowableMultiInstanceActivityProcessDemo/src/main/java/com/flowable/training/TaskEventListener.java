package com.flowable.training;

import org.flowable.engine.delegate.TaskListener;
import org.flowable.task.service.delegate.DelegateTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TaskEventListener implements TaskListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Logger logger = LoggerFactory.getLogger(TaskEventListener.class);

	@Override
	public void notify(DelegateTask delegateTask) {
		logger.info("Task event listner executing for event of type {}", delegateTask.getEventName());
		UserTaskInfo userTaskInfo = (UserTaskInfo) delegateTask.getVariable("userTaskInfo");
		logger.info("user : {}, task desc : {}", userTaskInfo.getUser(), userTaskInfo.getTaskDesc());
		
		logger.info("nrOfInstances : {}", delegateTask.getVariable("nrOfInstances"));
		logger.info("nrOfActiveInstances : {}", delegateTask.getVariable("nrOfActiveInstances"));
		logger.info("loopCounter : {}", delegateTask.getVariable("loopCounter"));
		
		logger.info("nrOfCompletedInstances : {}", delegateTask.getVariable("nrOfCompletedInstances"));

		

	}

}
