package com.flowable.training;

import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.test.FlowableRule;
import org.junit.Rule;
import org.junit.Test;

public class ProcessMultipleInstanceActivitytDemoTest {

	private String filename = "src/main/resources/diagrams/Multiple_Instance_Activity_Demo.bpmn";

	@Rule
	public FlowableRule activitiRule = new FlowableRule();

	@Test
	public void startProcess() throws Exception {
		RepositoryService repositoryService = activitiRule.getRepositoryService();
		System.out.println("Repository Service Started");
		repositoryService.createDeployment().addInputStream("Multiple_Instance_Activity_Demo.bpmn20.xml",
				new FileInputStream(filename)).deploy();
		System.out.println("Process is deployed");

		RuntimeService runtimeService = activitiRule.getRuntimeService();
		System.out.println("Runtime Service Started");
		
		List<UserTaskInfo> userTaskInfos = new ArrayList<>();
		
		UserTaskInfo userTaskInfo1 = new UserTaskInfo();
		userTaskInfo1.setTaskDesc("Task description 1");
		userTaskInfo1.setUser("Sumit");
		
		UserTaskInfo userTaskInfo2 = new UserTaskInfo();
		userTaskInfo2.setTaskDesc("Task description 2");
		userTaskInfo2.setUser("Nitin");
		
		UserTaskInfo userTaskInfo3 = new UserTaskInfo();
		userTaskInfo3.setTaskDesc("Task description 3");
		userTaskInfo3.setUser("Vipul");
		
		userTaskInfos.add(userTaskInfo1);
		userTaskInfos.add(userTaskInfo2);
		userTaskInfos.add(userTaskInfo3);
		
		Map<String, Object> variables = new HashMap<String, Object>();
		variables.put("userTaskInfos", userTaskInfos);
		
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("multiInstanceUserTaskProcesstDemo", variables);
		assertNotNull(processInstance.getId());
		System.out.println("id " + processInstance.getId() + " "+processInstance.getProcessDefinitionId());
	}
}