package com.example.demo.service;


import com.example.demo.entity.User;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class FileUploadServiceImpl implements FileUploadService {
    private String uploadFolderPath="D:/Sarika_Sandbhor/UploadedFiles/";
    @Override
    public ResponseEntity<Object> uploadToLocal(MultipartFile file, User user){
        try {
            byte[] data=file.getBytes();
            Path path= Paths.get(uploadFolderPath+file.getOriginalFilename());
            Files.write(path,data);
            System.out.println("file ka naam hai "+file.getOriginalFilename());
            System.out.println("file ka content type hai "+file.getContentType());
            System.out.println("user ka naam hai "+user.getUserName());
            System.out.println(user.getUserName()+" ka mobile number "+ user.getMobile());
            System.out.println(user.getUserName()+" ka email id "+ user.getEmail());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return ResponseEntity.ok("service working");
    }

    @Override
    public ResponseEntity<Object> uploadToLocal(MultipartFile file){
        try {
            byte[] data=file.getBytes();
            Path path= Paths.get(uploadFolderPath+file.getOriginalFilename());
            Files.write(path,data);
            System.out.println("file ka naam hai "+file.getOriginalFilename());
            System.out.println("file ka content type hai "+file.getContentType());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return ResponseEntity.ok("service working");
    }
}
