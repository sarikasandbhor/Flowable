package org.flowable.training;

import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.test.FlowableRule;
import org.junit.Rule;
import org.junit.Test;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

public class ProcessServiceTask {

    private String filename = "src/main/resources/diagrams/training_process.bpmn";

    @Rule
    public FlowableRule activitiRule = new FlowableRule();

    @Test
    public void startProcess() throws Exception {
            RepositoryService repositoryService = activitiRule.getRepositoryService();
            System.out.println("Repository Service Started");
            repositoryService.createDeployment().addInputStream("training_process.bpmn20.xml",
                    new FileInputStream(filename)).deploy();

            RuntimeService runtimeService = activitiRule.getRuntimeService();
            System.out.println("Runtime Service Started");

            Map<String, Object> variableMap = new HashMap<String, Object> ();
            variableMap.put("firstName", "Sarika");
            variableMap.put("lastName", "Sandbhor");
            variableMap.put("loanAmount",50000);

            ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("training_process",variableMap);
            System.out.println("Process is deployed");

            assertNotNull(processInstance.getId());
            System.out.println("id " + processInstance.getId() + " " + processInstance.getProcessDefinitionId());
            System.out.println("Service Task Execution Completed");
        }

    }
