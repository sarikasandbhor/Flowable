package org.flowable.training;

import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.Execution;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.test.FlowableRule;
import org.junit.Rule;
import org.junit.Test;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

public class ProcessMessageEvent {

    private String filename = "src/main/resources/diagrams/Message_Event.bpmn";

    @Rule
    public FlowableRule activitiRule = new FlowableRule();

    @Test
    public void startProcess() throws Exception {
        RepositoryService repositoryService = activitiRule.getRepositoryService();
        System.out.println("Repository Service Started");
        repositoryService.createDeployment().addInputStream("Message_Event.bpmn20.xml",
                new FileInputStream(filename)).deploy();

        RuntimeService runtimeService = activitiRule.getRuntimeService();
        System.out.println("Runtime Service Started");

        Map<String, Object> variableMap = new HashMap<String, Object> ();
        variableMap.put("customerName", "Sarika");
        variableMap.put("amount", 1000);
        variableMap.put("orderSource", "Web");

        ProcessInstance processInstance = runtimeService.startProcessInstanceByMessage("order_by_broker",variableMap);
        System.out.println("Process is deployed");

        assertNotNull(processInstance.getId());
        System.out.println("id " + processInstance.getId() + " " + processInstance.getProcessDefinitionId());



         Execution execution = runtimeService.createExecutionQuery().processInstanceId(processInstance.getProcessInstanceId()).messageEventSubscriptionName("payment_received").singleResult();
        runtimeService.messageEventReceived("payment_received",execution.getId());

       /* execution = runtimeService.createExecutionQuery().processInstanceId(processInstance.getProcessInstanceId()).messageEventSubscriptionName("shipping_cancelled").singleResult();
        runtimeService.messageEventReceived("shipping_cancelled",execution.getId());*/


        System.out.println("Service Task Execution Completed");
    }

}
