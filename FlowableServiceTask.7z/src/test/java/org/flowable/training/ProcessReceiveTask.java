package org.flowable.training;

import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.Execution;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.test.FlowableRule;
import org.junit.Rule;
import org.junit.Test;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

public class ProcessReceiveTask {

    private String filename = "src/main/resources/diagrams/Receive_Task.bpmn";

    @Rule
    public FlowableRule activitiRule = new FlowableRule();

    @Test
    public void startProcess() throws Exception {
        RepositoryService repositoryService = activitiRule.getRepositoryService();
        System.out.println("Repository Service Started");
        repositoryService.createDeployment().addInputStream("Receive_Task.bpmn20.xml",
                new FileInputStream(filename)).deploy();

        RuntimeService runtimeService = activitiRule.getRuntimeService();
        System.out.println("Runtime Service Started");

        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("Receive_Task");
        System.out.println("Process is deployed");

        assertNotNull(processInstance.getId());
        System.out.println("id " + processInstance.getId() + " " + processInstance.getProcessDefinitionId());

        Execution execution = runtimeService.createExecutionQuery().processInstanceId(processInstance.getProcessInstanceId()).activityId("wait_for_patient_confirmation").singleResult();

        Map<String,Object> variableMap = new HashMap<String, Object>();
        variableMap.put("acceptanceStatus",Boolean.TRUE);

        runtimeService.trigger(execution.getId(),variableMap);

        System.out.println("Service Task Execution Completed");
    }

}
