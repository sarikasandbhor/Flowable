package org.flowable.training;

import org.flowable.engine.delegate.TaskListener;
import org.flowable.task.service.delegate.DelegateTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TaskEventListener implements TaskListener {

    private static final long serialVersionUID = 1L;
    Logger logger = LoggerFactory.getLogger(TaskEventListener.class);

    @Override
    public void notify(DelegateTask delegateTask) {
        logger.info("Task event listener executing for event of type : {}, task name : {}", delegateTask.getEventName(), delegateTask.getName());
    }
}
