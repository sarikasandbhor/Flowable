package org.flowable.training;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoanApprovalService implements JavaDelegate {

    Logger logger = (Logger) LoggerFactory.getLogger(LoanApprovalService.class);

    @Override
    public void execute(final DelegateExecution execution) {
        String firstName = (String) execution.getVariable("firstName");
        String lastName = (String) execution.getVariable("lastName");
        Integer loanAmount = (Integer) execution.getVariable("loanAmount");

        logger.info("FirstName : {} "+firstName);
        logger.info(" LastName : {}"+lastName);
        logger.info(" LoanAmount : {}"+loanAmount);

        if(loanAmount < 10000)
        {
            execution.setVariable("isLoanApproved",false);
        }
        else if(loanAmount>=10000 && loanAmount<30000)
        {
            execution.setVariable("isLoanApproved",true);
            execution.setVariable("loanInterest", 7);
        }
        else
        {
            execution.setVariable("isLoanApproved",true);
            execution.setVariable("loanInterest", 8);
        }
        logger.info("Is Loan Approved : "+execution.getVariable("isLoanApproved") +" Loan Interest : "+execution.getVariable("loanInterest"));
    }
}
