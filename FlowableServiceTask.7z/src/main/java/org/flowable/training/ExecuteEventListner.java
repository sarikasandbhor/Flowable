package org.flowable.training;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExecuteEventListner implements ExecutionListener {

    private static final long serialVersionUID = 1L;
    Logger logger = LoggerFactory.getLogger(ExecuteEventListner.class);

    @Override
    public void notify(DelegateExecution delegateExecution) {
        logger.info("Event Name :{}"+delegateExecution.getEventName()+"Activity ID :{}"+delegateExecution.getCurrentActivityId());logger.info("Event Name :{}"+delegateExecution.getEventName()+"Activity ID :{}"+delegateExecution.getCurrentActivityId());
    }
}
