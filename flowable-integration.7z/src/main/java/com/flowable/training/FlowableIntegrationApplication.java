package com.flowable.training;

import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;
import java.util.List;

@SpringBootApplication
public class FlowableIntegrationApplication {
	Logger logger = LoggerFactory.getLogger(FlowableIntegrationApplication.class);

	@Autowired
	public RuntimeService runtimeService;

	public static void main(String[] args) {
		SpringApplication.run(FlowableIntegrationApplication.class, args);
	}

	@PostConstruct
	public void  fetchProcessInstance(){
		List<ProcessInstance> processInstances = runtimeService.createProcessInstanceQuery().active().list();
		logger.info("Active Process Instances :"+processInstances.size());
	}
}
