package com.flowable.training.service;

import com.flowable.training.pojo.ProcessInstanceJson;

import java.util.List;
import java.util.Map;

public interface ProcessDefinitionService {
    public String startProcessInstance(String processKey,Map<String, Object> processVariables);

    public List<ProcessInstanceJson> getProcessInstances();
}
