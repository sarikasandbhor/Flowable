package com.flowable.training.service;

import com.flowable.training.pojo.DecisionTableInputJson;
import org.flowable.dmn.api.DmnDecisionService;
import org.flowable.dmn.engine.test.DmnDeploymentAnnotation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;



@Service
public class DecisionServiceImpl implements DecisionService{

    Logger logger = LoggerFactory.getLogger(DecisionServiceImpl.class);
    @Autowired
    private DmnDecisionService dmnDecisionService;


    @Override
    @DmnDeploymentAnnotation
    public Map<String, Object> executeDecision(String decisionTableKey, Map<String, Object> decisionVars) {
        Map<String,Object> executionResult = null;
        Map<String,Object> executionResult1 = null;
        try {
            executionResult = dmnDecisionService.createExecuteDecisionBuilder()
                    .decisionKey(decisionTableKey).variables(decisionVars).executeWithSingleResult();


        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("Execution Decision Result ==>" + executionResult);
        return executionResult;
    }

    @DmnDeploymentAnnotation
    public Map<String, Object> executeDecisionService(String decisionTableKey, Map<String, Object> decisionVars) {
        Map<String,Object> executionResult = null;
        try {
            executionResult = dmnDecisionService.createExecuteDecisionBuilder()
                    .decisionKey(decisionTableKey).variables(decisionVars).executeDecisionServiceWithSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("Execution Decision Result ==>" + executionResult);
        return executionResult;
    }


}
