package com.flowable.training.service;

import com.flowable.training.pojo.TaskInstanceJson;

import java.util.List;
import java.util.Map;

public interface TaskInstanceService {

   public List<TaskInstanceJson> getTasks(String assignee);

   public String claimTask(String taskId, String userId);

   public String completeTask(String taskId, Map<String,Object> taskVariables);
}

