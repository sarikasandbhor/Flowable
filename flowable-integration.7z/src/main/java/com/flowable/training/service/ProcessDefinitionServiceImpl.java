package com.flowable.training.service;

import com.flowable.training.pojo.ProcessInstanceJson;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.spring.boot.ProcessEngineServicesAutoConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ProcessDefinitionServiceImpl implements ProcessDefinitionService {

    Logger logger = LoggerFactory.getLogger(ProcessDefinitionServiceImpl.class);
    @Autowired
    public RuntimeService runtimeService;
    @Override
    public String startProcessInstance(String processKey, Map<String, Object> processVariables) {

        logger.info("Process started"+processKey);
        ProcessInstance processInstance = null;
        try {
            processInstance = runtimeService.startProcessInstanceByKey(processKey, processVariables);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        logger.info("ProcessInstanceId :"+processInstance.getProcessInstanceId());
        return processInstance.getProcessInstanceId();
    }

    @Override
    public List<ProcessInstanceJson> getProcessInstances() {
        List<ProcessInstanceJson> processInstanceJsons = new ArrayList<ProcessInstanceJson>();
        try {
            List<ProcessInstance> processInstances = runtimeService.createProcessInstanceQuery().active().list();
            for(ProcessInstance processInstance:processInstances ){
                ProcessInstanceJson processInstanceJson = new ProcessInstanceJson();
                processInstanceJson.setProcessInstanceId(processInstance.getProcessInstanceId());
                processInstanceJson.setProcessDefinitionId(processInstance.getProcessDefinitionKey());
                processInstanceJson.setStartDate(processInstance.getStartTime());
                processInstanceJson.setStartUser(processInstance.getStartUserId());
                processInstanceJsons.add(processInstanceJson);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return processInstanceJsons;
    }
}
