package com.flowable.training.service;

import com.flowable.training.pojo.TaskInstanceJson;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class TaskInstanceServiceImpl implements TaskInstanceService{

    Logger logger = LoggerFactory.getLogger(TaskInstanceServiceImpl.class);

    @Autowired
    public TaskService taskInstanceService;

    @Override
    public List<TaskInstanceJson> getTasks(String assignee) {
        logger.info("Task assigned to assingee :"+assignee);
        List<TaskInstanceJson> taskInstanceJsons = new ArrayList<TaskInstanceJson>();
        try {
            List<Task> tasks = taskInstanceService.createTaskQuery().active().taskAssigned().list();
            for(Task task : tasks)
            {
               TaskInstanceJson taskInstanceJson = new TaskInstanceJson();
               taskInstanceJson.setTaskId(task.getId());
               taskInstanceJson.setTaskName(task.getTaskDefinitionKey());
               taskInstanceJson.setTaskStartTime(task.getCreateTime());
               taskInstanceJson.setTaskAssignedTo(task.getAssignee());
               taskInstanceJson.setProcessDefinitionId(task.getProcessDefinitionId());
               taskInstanceJsons.add(taskInstanceJson);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return taskInstanceJsons;
    }

    @Override
    public String claimTask(String taskId, String userId) {
        taskInstanceService.claim(taskId,userId);
        logger.info("Task with taskID "+taskId+" claimed by user "+userId);
        return "Task is claimed!";
    }

    @Override
    public String completeTask(String taskId, Map<String,Object> taskVariables) {
        taskInstanceService.complete(taskId,taskVariables);
        logger.info("Task with taskID "+taskId+" completed.");
        return "Task is completed!";
    }
}
