package com.flowable.training.service;

import com.flowable.training.pojo.DecisionTableInputJson;

import java.util.Map;

public interface DecisionService {
    public Map<String,Object> executeDecision(String decisionTableKey, Map<String,Object> decisionVars);
    public Map<String,Object> executeDecisionService(String decisionTableKey, Map<String,Object> decisionVars);
}
