package com.flowable.training.controller;

import com.flowable.training.pojo.ProcessInstanceJson;
import com.flowable.training.pojo.TaskInstanceJson;
import com.flowable.training.service.ProcessDefinitionService;
import com.flowable.training.service.TaskInstanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
public class ProcessController {

    @Autowired
    private ProcessDefinitionService processDefinitionService;
    @Autowired
    public TaskInstanceService taskInstanceService;


    @PostMapping("/startProcess")
    public ResponseEntity<String> startProcessInstance(@RequestParam("processKey") String processId, @RequestBody Map<String,Object> processVariables){

        return new ResponseEntity<String>(processDefinitionService.startProcessInstance(processId,processVariables), HttpStatus.CREATED);

    }
    @GetMapping("/instances")
    public ResponseEntity<List<ProcessInstanceJson>> getProcessInstances()
    {
        return new ResponseEntity<List<ProcessInstanceJson>>(processDefinitionService.getProcessInstances(), HttpStatus.OK);
    }

    @GetMapping("/tasks")
    public ResponseEntity<List<TaskInstanceJson>> getTasks(String assignee){

        return new ResponseEntity<List<TaskInstanceJson>>(taskInstanceService.getTasks(assignee), HttpStatus.CREATED);
    }

    @PostMapping("/claimTask")
    public void startProcessService(@RequestParam("taskId") String taskId, @RequestParam("taskDefinitionKey") String userId) {
        taskInstanceService.claimTask(taskId,userId);
    }

    @PostMapping("/completeTask")
    public void completeTask(@RequestParam("taskId") String taskId, @RequestBody Map<String,Object> taskVariables){
        taskInstanceService.completeTask(taskId,taskVariables);
    }

}
