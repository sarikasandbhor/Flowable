package com.flowable.training.controller;

import com.flowable.training.pojo.DecisionTableInputJson;
import com.flowable.training.service.DecisionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class DecisionController {

    @Autowired
    private DecisionService decisionService;

    //From Decision Table
    @GetMapping("/getDecision")
    public ResponseEntity<Map<String,Object>> getDecision(@RequestParam("decisionKey") String decisionKey, @RequestBody Map<String,Object> decisionVars)
    {
        return new ResponseEntity<>(decisionService.executeDecision(decisionKey,decisionVars), HttpStatus.OK);
    }

    //From Decision Service
    @GetMapping("/getDecision1")
    public ResponseEntity<Map<String,Object>> getDecisionFromService(@RequestParam("decisionKey") String decisionKey, @RequestBody Map<String,Object> decisionVars)
    {
        return new ResponseEntity<>(decisionService.executeDecisionService(decisionKey,decisionVars), HttpStatus.OK);
    }
}
