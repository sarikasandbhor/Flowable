package com.flowable.training.pojo;

import java.util.Date;

public class TaskInstanceJson {

   private String taskName;
   private String taskId;
   private String taskAssignedTo;
   private Date taskStartTime;
   private String processDefinitionId;

   public String getProcessDefinitionId() {
      return processDefinitionId;
   }

   public void setProcessDefinitionId(String processDefinitionId) {
      this.processDefinitionId = processDefinitionId;
   }

   public String getTaskName() {
      return taskName;
   }

   public void setTaskName(String taskName) {
      this.taskName = taskName;
   }

   public String getTaskId() {
      return taskId;
   }

   public void setTaskId(String taskId) {
      this.taskId = taskId;
   }

   public String getTaskAssignedTo() {
      return taskAssignedTo;
   }

   public void setTaskAssignedTo(String taskAssignedTo) {
      this.taskAssignedTo = taskAssignedTo;
   }

   public Date getTaskStartTime() {
      return taskStartTime;
   }

   public void setTaskStartTime(Date taskStartTime) {
      this.taskStartTime = taskStartTime;
   }

}
